<?php

namespace App\Models\Traits\Casts;

enum NivelArea: string
{
    case Secundaria = 'secundaria';
    case Primaria = 'primaria';
}